const nivelFacil = "1";
const nivelDificil = "2";

const vidaNivelFacil = 1000;
const vidaNivelDificil = 500;

const forcaInicialFacil   = 1000;
const forcaInicialDificil = 50;

const forcaInicialInimigoFacil   = 800;
const forcaInicialInimigoDificil = 75;

const vidaMonstroNivelFacil = 700;
const vidaMonstroNivelDificil = 600;

//Exports
exports.nivelDificil = nivelDificil;
exports.nivelFacil = nivelFacil;

exports.vidaMonstroNivelFacil = vidaMonstroNivelFacil;
exports.vidaMonstroNivelDificil = vidaMonstroNivelDificil;

exports.vidaNivelFacil = vidaNivelFacil;
exports.vidaNivelDificil = vidaNivelDificil;

exports.forcaInicialFacil = forcaInicialFacil;
exports.forcaInicialDificil = forcaInicialDificil;

exports.forcaInicialInimigoFacil = forcaInicialInimigoFacil;
exports.forcaInicialInimigoDificil = forcaInicialInimigoDificil;