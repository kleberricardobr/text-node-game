const { println, limparConsole, pause } = require("../utils/utils")

module.exports = () => {
    limparConsole();
    println("Jogo desenvolvido sobre critérios didáticos com base no Bootcamp da ITalents.");
    println("Implementação realizado por Kleber Ricardo.");
    println("LinkedIn: https://www.linkedin.com/in/kleber-ricardo-0a306210b/");
    println("Obrigado por testar!");
    pause();
    limparConsole();
}